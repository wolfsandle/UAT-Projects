﻿namespace InnovationPlatform
{
    partial class SubmitAnIdea
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SubmitAnIdea));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.welcomeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.submitAnIdeaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reviewIdeasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.voteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.radioButtonCost = new System.Windows.Forms.RadioButton();
            this.radioButtonSchedule = new System.Windows.Forms.RadioButton();
            this.radioButtonClient = new System.Windows.Forms.RadioButton();
            this.radioButtonVendor = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.radioButtonTools = new System.Windows.Forms.RadioButton();
            this.radioButtonTechnology = new System.Windows.Forms.RadioButton();
            this.radioButtonSoftware = new System.Windows.Forms.RadioButton();
            this.radioButtonProcess = new System.Windows.Forms.RadioButton();
            this.radioButtonPersonnel = new System.Windows.Forms.RadioButton();
            this.radioButtonOther = new System.Windows.Forms.RadioButton();
            this.groupBoxScope = new System.Windows.Forms.GroupBox();
            this.textBoxIdeaDescription = new System.Windows.Forms.TextBox();
            this.labelIdeaDescription = new System.Windows.Forms.Label();
            this.labelfirstName = new System.Windows.Forms.Label();
            this.labelLastName = new System.Windows.Forms.Label();
            this.textBoxFirstName = new System.Windows.Forms.TextBox();
            this.textBoxLastName = new System.Windows.Forms.TextBox();
            this.labelBusinessUnit = new System.Windows.Forms.Label();
            this.labelOffice = new System.Windows.Forms.Label();
            this.textBoxEmail = new System.Windows.Forms.TextBox();
            this.labelEmail = new System.Windows.Forms.Label();
            this.comboBoxBusinessUnit = new System.Windows.Forms.ComboBox();
            this.comboBoxOffice = new System.Windows.Forms.ComboBox();
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.menuStrip1.SuspendLayout();
            this.groupBoxScope.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.welcomeToolStripMenuItem,
            this.submitAnIdeaToolStripMenuItem,
            this.reviewIdeasToolStripMenuItem,
            this.voteToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1008, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // welcomeToolStripMenuItem
            // 
            this.welcomeToolStripMenuItem.Name = "welcomeToolStripMenuItem";
            this.welcomeToolStripMenuItem.Size = new System.Drawing.Size(69, 20);
            this.welcomeToolStripMenuItem.Text = "Welcome";
            this.welcomeToolStripMenuItem.Click += new System.EventHandler(this.welcomeToolStripMenuItem_Click);
            // 
            // submitAnIdeaToolStripMenuItem
            // 
            this.submitAnIdeaToolStripMenuItem.BackColor = System.Drawing.SystemColors.Control;
            this.submitAnIdeaToolStripMenuItem.Name = "submitAnIdeaToolStripMenuItem";
            this.submitAnIdeaToolStripMenuItem.Size = new System.Drawing.Size(98, 20);
            this.submitAnIdeaToolStripMenuItem.Text = "Submit an Idea";
            // 
            // reviewIdeasToolStripMenuItem
            // 
            this.reviewIdeasToolStripMenuItem.Name = "reviewIdeasToolStripMenuItem";
            this.reviewIdeasToolStripMenuItem.Size = new System.Drawing.Size(86, 20);
            this.reviewIdeasToolStripMenuItem.Text = "Review Ideas";
            this.reviewIdeasToolStripMenuItem.Click += new System.EventHandler(this.reviewIdeasToolStripMenuItem_Click);
            // 
            // voteToolStripMenuItem
            // 
            this.voteToolStripMenuItem.Name = "voteToolStripMenuItem";
            this.voteToolStripMenuItem.Size = new System.Drawing.Size(42, 20);
            this.voteToolStripMenuItem.Text = "Vote";
            this.voteToolStripMenuItem.Click += new System.EventHandler(this.voteToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(12, 20);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.AliceBlue;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(38, 537);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(288, 41);
            this.button1.TabIndex = 1;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // radioButtonCost
            // 
            this.radioButtonCost.AutoSize = true;
            this.radioButtonCost.Location = new System.Drawing.Point(31, 65);
            this.radioButtonCost.Name = "radioButtonCost";
            this.radioButtonCost.Size = new System.Drawing.Size(65, 28);
            this.radioButtonCost.TabIndex = 2;
            this.radioButtonCost.Text = "Cost";
            this.radioButtonCost.UseVisualStyleBackColor = true;
            // 
            // radioButtonSchedule
            // 
            this.radioButtonSchedule.AutoSize = true;
            this.radioButtonSchedule.Location = new System.Drawing.Point(31, 161);
            this.radioButtonSchedule.Name = "radioButtonSchedule";
            this.radioButtonSchedule.Size = new System.Drawing.Size(109, 28);
            this.radioButtonSchedule.TabIndex = 3;
            this.radioButtonSchedule.Text = "Schedule";
            this.radioButtonSchedule.UseVisualStyleBackColor = true;
            // 
            // radioButtonClient
            // 
            this.radioButtonClient.AutoSize = true;
            this.radioButtonClient.Location = new System.Drawing.Point(31, 33);
            this.radioButtonClient.Name = "radioButtonClient";
            this.radioButtonClient.Size = new System.Drawing.Size(75, 28);
            this.radioButtonClient.TabIndex = 4;
            this.radioButtonClient.Text = "Client";
            this.radioButtonClient.UseVisualStyleBackColor = true;
            // 
            // radioButtonVendor
            // 
            this.radioButtonVendor.AutoSize = true;
            this.radioButtonVendor.Location = new System.Drawing.Point(31, 289);
            this.radioButtonVendor.Name = "radioButtonVendor";
            this.radioButtonVendor.Size = new System.Drawing.Size(91, 28);
            this.radioButtonVendor.TabIndex = 5;
            this.radioButtonVendor.Text = "Vendor";
            this.radioButtonVendor.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(215, 82);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 24);
            this.label1.TabIndex = 6;
            // 
            // radioButtonTools
            // 
            this.radioButtonTools.AutoSize = true;
            this.radioButtonTools.Location = new System.Drawing.Point(31, 257);
            this.radioButtonTools.Name = "radioButtonTools";
            this.radioButtonTools.Size = new System.Drawing.Size(75, 28);
            this.radioButtonTools.TabIndex = 7;
            this.radioButtonTools.Text = "Tools";
            this.radioButtonTools.UseVisualStyleBackColor = true;
            // 
            // radioButtonTechnology
            // 
            this.radioButtonTechnology.AutoSize = true;
            this.radioButtonTechnology.Location = new System.Drawing.Point(31, 225);
            this.radioButtonTechnology.Name = "radioButtonTechnology";
            this.radioButtonTechnology.Size = new System.Drawing.Size(129, 28);
            this.radioButtonTechnology.TabIndex = 8;
            this.radioButtonTechnology.Text = "Technology";
            this.radioButtonTechnology.UseVisualStyleBackColor = true;
            // 
            // radioButtonSoftware
            // 
            this.radioButtonSoftware.AutoSize = true;
            this.radioButtonSoftware.Location = new System.Drawing.Point(31, 193);
            this.radioButtonSoftware.Name = "radioButtonSoftware";
            this.radioButtonSoftware.Size = new System.Drawing.Size(100, 28);
            this.radioButtonSoftware.TabIndex = 9;
            this.radioButtonSoftware.Text = "Software";
            this.radioButtonSoftware.UseVisualStyleBackColor = true;
            // 
            // radioButtonProcess
            // 
            this.radioButtonProcess.AutoSize = true;
            this.radioButtonProcess.Location = new System.Drawing.Point(31, 129);
            this.radioButtonProcess.Name = "radioButtonProcess";
            this.radioButtonProcess.Size = new System.Drawing.Size(96, 28);
            this.radioButtonProcess.TabIndex = 10;
            this.radioButtonProcess.Text = "Process";
            this.radioButtonProcess.UseVisualStyleBackColor = true;
            // 
            // radioButtonPersonnel
            // 
            this.radioButtonPersonnel.AutoSize = true;
            this.radioButtonPersonnel.Location = new System.Drawing.Point(31, 97);
            this.radioButtonPersonnel.Name = "radioButtonPersonnel";
            this.radioButtonPersonnel.Size = new System.Drawing.Size(114, 28);
            this.radioButtonPersonnel.TabIndex = 11;
            this.radioButtonPersonnel.Text = "Personnel";
            this.radioButtonPersonnel.UseVisualStyleBackColor = true;
            // 
            // radioButtonOther
            // 
            this.radioButtonOther.AutoSize = true;
            this.radioButtonOther.Checked = true;
            this.radioButtonOther.Location = new System.Drawing.Point(31, 344);
            this.radioButtonOther.Name = "radioButtonOther";
            this.radioButtonOther.Size = new System.Drawing.Size(75, 28);
            this.radioButtonOther.TabIndex = 12;
            this.radioButtonOther.TabStop = true;
            this.radioButtonOther.Text = "Other";
            this.radioButtonOther.UseVisualStyleBackColor = true;
            // 
            // groupBoxScope
            // 
            this.groupBoxScope.BackColor = System.Drawing.Color.AliceBlue;
            this.groupBoxScope.Controls.Add(this.radioButtonOther);
            this.groupBoxScope.Controls.Add(this.radioButtonPersonnel);
            this.groupBoxScope.Controls.Add(this.radioButtonProcess);
            this.groupBoxScope.Controls.Add(this.radioButtonSoftware);
            this.groupBoxScope.Controls.Add(this.radioButtonTechnology);
            this.groupBoxScope.Controls.Add(this.radioButtonTools);
            this.groupBoxScope.Controls.Add(this.radioButtonVendor);
            this.groupBoxScope.Controls.Add(this.radioButtonClient);
            this.groupBoxScope.Controls.Add(this.radioButtonSchedule);
            this.groupBoxScope.Controls.Add(this.radioButtonCost);
            this.groupBoxScope.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBoxScope.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxScope.Location = new System.Drawing.Point(695, 58);
            this.groupBoxScope.Name = "groupBoxScope";
            this.groupBoxScope.Size = new System.Drawing.Size(269, 398);
            this.groupBoxScope.TabIndex = 13;
            this.groupBoxScope.TabStop = false;
            this.groupBoxScope.Text = "Innovation Scope";
            this.groupBoxScope.Enter += new System.EventHandler(this.groupBoxScope_Enter);
            // 
            // textBoxIdeaDescription
            // 
            this.textBoxIdeaDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxIdeaDescription.Location = new System.Drawing.Point(38, 288);
            this.textBoxIdeaDescription.Multiline = true;
            this.textBoxIdeaDescription.Name = "textBoxIdeaDescription";
            this.textBoxIdeaDescription.Size = new System.Drawing.Size(600, 227);
            this.textBoxIdeaDescription.TabIndex = 14;
            this.textBoxIdeaDescription.TextChanged += new System.EventHandler(this.textBoxIdeaDescription_TextChanged);
            // 
            // labelIdeaDescription
            // 
            this.labelIdeaDescription.AutoSize = true;
            this.labelIdeaDescription.BackColor = System.Drawing.Color.Transparent;
            this.labelIdeaDescription.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelIdeaDescription.ForeColor = System.Drawing.Color.White;
            this.labelIdeaDescription.Location = new System.Drawing.Point(32, 251);
            this.labelIdeaDescription.Name = "labelIdeaDescription";
            this.labelIdeaDescription.Size = new System.Drawing.Size(145, 24);
            this.labelIdeaDescription.TabIndex = 15;
            this.labelIdeaDescription.Text = "Idea Description";
            // 
            // labelfirstName
            // 
            this.labelfirstName.AutoSize = true;
            this.labelfirstName.BackColor = System.Drawing.Color.Transparent;
            this.labelfirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelfirstName.ForeColor = System.Drawing.Color.White;
            this.labelfirstName.Location = new System.Drawing.Point(32, 61);
            this.labelfirstName.Name = "labelfirstName";
            this.labelfirstName.Size = new System.Drawing.Size(101, 24);
            this.labelfirstName.TabIndex = 16;
            this.labelfirstName.Text = "First Name";
            // 
            // labelLastName
            // 
            this.labelLastName.AutoSize = true;
            this.labelLastName.BackColor = System.Drawing.Color.Transparent;
            this.labelLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelLastName.ForeColor = System.Drawing.Color.White;
            this.labelLastName.Location = new System.Drawing.Point(32, 99);
            this.labelLastName.Name = "labelLastName";
            this.labelLastName.Size = new System.Drawing.Size(99, 24);
            this.labelLastName.TabIndex = 17;
            this.labelLastName.Text = "Last Name";
            // 
            // textBoxFirstName
            // 
            this.textBoxFirstName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxFirstName.Location = new System.Drawing.Point(143, 58);
            this.textBoxFirstName.Name = "textBoxFirstName";
            this.textBoxFirstName.Size = new System.Drawing.Size(495, 29);
            this.textBoxFirstName.TabIndex = 18;
            // 
            // textBoxLastName
            // 
            this.textBoxLastName.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxLastName.Location = new System.Drawing.Point(143, 95);
            this.textBoxLastName.Name = "textBoxLastName";
            this.textBoxLastName.Size = new System.Drawing.Size(495, 29);
            this.textBoxLastName.TabIndex = 19;
            // 
            // labelBusinessUnit
            // 
            this.labelBusinessUnit.AutoSize = true;
            this.labelBusinessUnit.BackColor = System.Drawing.Color.Transparent;
            this.labelBusinessUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBusinessUnit.ForeColor = System.Drawing.Color.White;
            this.labelBusinessUnit.Location = new System.Drawing.Point(32, 175);
            this.labelBusinessUnit.Name = "labelBusinessUnit";
            this.labelBusinessUnit.Size = new System.Drawing.Size(207, 24);
            this.labelBusinessUnit.TabIndex = 21;
            this.labelBusinessUnit.Text = "Assigned Business Unit";
            // 
            // labelOffice
            // 
            this.labelOffice.AutoSize = true;
            this.labelOffice.BackColor = System.Drawing.Color.Transparent;
            this.labelOffice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelOffice.ForeColor = System.Drawing.Color.White;
            this.labelOffice.Location = new System.Drawing.Point(32, 213);
            this.labelOffice.Name = "labelOffice";
            this.labelOffice.Size = new System.Drawing.Size(218, 24);
            this.labelOffice.TabIndex = 22;
            this.labelOffice.Text = "Assigned Office Location";
            // 
            // textBoxEmail
            // 
            this.textBoxEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEmail.Location = new System.Drawing.Point(143, 132);
            this.textBoxEmail.Name = "textBoxEmail";
            this.textBoxEmail.Size = new System.Drawing.Size(495, 29);
            this.textBoxEmail.TabIndex = 25;
            // 
            // labelEmail
            // 
            this.labelEmail.AutoSize = true;
            this.labelEmail.BackColor = System.Drawing.Color.Transparent;
            this.labelEmail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelEmail.ForeColor = System.Drawing.Color.White;
            this.labelEmail.Location = new System.Drawing.Point(32, 137);
            this.labelEmail.Name = "labelEmail";
            this.labelEmail.Size = new System.Drawing.Size(63, 24);
            this.labelEmail.TabIndex = 24;
            this.labelEmail.Text = "E-Mail";
            // 
            // comboBoxBusinessUnit
            // 
            this.comboBoxBusinessUnit.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxBusinessUnit.FormattingEnabled = true;
            this.comboBoxBusinessUnit.Items.AddRange(new object[] {
            "Building",
            "Environmental",
            "Forestry",
            "Infrastructure",
            "Mining",
            "Transportation",
            "Power",
            "Properties",
            "Oil and Gas",
            "Communications"});
            this.comboBoxBusinessUnit.Location = new System.Drawing.Point(263, 169);
            this.comboBoxBusinessUnit.Name = "comboBoxBusinessUnit";
            this.comboBoxBusinessUnit.Size = new System.Drawing.Size(375, 32);
            this.comboBoxBusinessUnit.TabIndex = 26;
            this.comboBoxBusinessUnit.SelectedIndexChanged += new System.EventHandler(this.comboBoxBusinessUnit_SelectedIndexChanged);
            // 
            // comboBoxOffice
            // 
            this.comboBoxOffice.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxOffice.FormattingEnabled = true;
            this.comboBoxOffice.Items.AddRange(new object[] {
            "Alberta",
            "British Columbia",
            "California",
            "Hawaii",
            "Illinois",
            "Kentucky",
            "Manitoba",
            "Nevada",
            "Northwest Territories",
            "Ontario",
            "Saskatchewan",
            "Texas",
            "Washington"});
            this.comboBoxOffice.Location = new System.Drawing.Point(263, 209);
            this.comboBoxOffice.Name = "comboBoxOffice";
            this.comboBoxOffice.Size = new System.Drawing.Size(375, 32);
            this.comboBoxOffice.TabIndex = 27;
            this.comboBoxOffice.SelectedIndexChanged += new System.EventHandler(this.comboBoxOffice_SelectedIndexChanged);
            // 
            // errorProvider
            // 
            this.errorProvider.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.errorProvider.ContainerControl = this;
            // 
            // SubmitAnIdea
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::InnovationPlatform.Properties.Resources.background;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1008, 601);
            this.Controls.Add(this.comboBoxOffice);
            this.Controls.Add(this.comboBoxBusinessUnit);
            this.Controls.Add(this.textBoxEmail);
            this.Controls.Add(this.labelEmail);
            this.Controls.Add(this.labelOffice);
            this.Controls.Add(this.labelBusinessUnit);
            this.Controls.Add(this.textBoxLastName);
            this.Controls.Add(this.textBoxFirstName);
            this.Controls.Add(this.labelLastName);
            this.Controls.Add(this.labelfirstName);
            this.Controls.Add(this.labelIdeaDescription);
            this.Controls.Add(this.textBoxIdeaDescription);
            this.Controls.Add(this.groupBoxScope);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SubmitAnIdea";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Submit An Idea";
            this.Load += new System.EventHandler(this.SubmitAnIdea_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBoxScope.ResumeLayout(false);
            this.groupBoxScope.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem welcomeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem submitAnIdeaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reviewIdeasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem voteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton radioButtonCost;
        private System.Windows.Forms.RadioButton radioButtonSchedule;
        private System.Windows.Forms.RadioButton radioButtonClient;
        private System.Windows.Forms.RadioButton radioButtonVendor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton radioButtonTools;
        private System.Windows.Forms.RadioButton radioButtonTechnology;
        private System.Windows.Forms.RadioButton radioButtonSoftware;
        private System.Windows.Forms.RadioButton radioButtonProcess;
        private System.Windows.Forms.RadioButton radioButtonPersonnel;
        private System.Windows.Forms.RadioButton radioButtonOther;
        private System.Windows.Forms.GroupBox groupBoxScope;
        private System.Windows.Forms.TextBox textBoxIdeaDescription;
        private System.Windows.Forms.Label labelIdeaDescription;
        private System.Windows.Forms.Label labelfirstName;
        private System.Windows.Forms.Label labelLastName;
        private System.Windows.Forms.TextBox textBoxFirstName;
        private System.Windows.Forms.TextBox textBoxLastName;
        private System.Windows.Forms.Label labelBusinessUnit;
        private System.Windows.Forms.Label labelOffice;
        private System.Windows.Forms.TextBox textBoxEmail;
        private System.Windows.Forms.Label labelEmail;
        private System.Windows.Forms.ComboBox comboBoxBusinessUnit;
        private System.Windows.Forms.ComboBox comboBoxOffice;
        private System.Windows.Forms.ErrorProvider errorProvider;
    }
}

