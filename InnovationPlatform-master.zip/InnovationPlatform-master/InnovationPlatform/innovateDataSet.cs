﻿namespace InnovationPlatform
{


    partial class innovateDataSet
    {
    }
}

namespace InnovationPlatform.innovateDataSetTableAdapters {
    
    
    public partial class ideaTableAdapter {
    }
}
