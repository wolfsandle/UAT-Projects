﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnovationPlatform
{
    public partial class ReviewIdeas : Form
    {
        User reviewusr = new User();
        public ReviewIdeas(User submitusr) //carries user data from submit to review form
        {
            InitializeComponent();

            reviewusr.FirstName = submitusr.FirstName;
            reviewusr.LastName = submitusr.LastName;
            reviewusr.Email = submitusr.Email;
        }

        private void submitAnIdeaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SubmitAnIdea sAIForm = new SubmitAnIdea(reviewusr);
            sAIForm.Show();
            this.Dispose(false);
        }

        private void welcomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Welcome welcomeForm = new Welcome(reviewusr);
            welcomeForm.Show();
            this.Hide();
        }

        private void reviewIdeasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReviewIdeas rIForm = new ReviewIdeas(reviewusr);
            rIForm.Show();
            this.Dispose(false);
        }

        private void voteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VoteIdeas vIForm = new VoteIdeas(reviewusr);
            vIForm.Show();
            this.Dispose(false);
        }

        private void ReviewIdeas_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'innovateDataSet.idea' table. You can move, or remove it, as needed.
            this.ideaTableAdapter.Fill(this.innovateDataSet.idea);

        }
        private void DataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1) //if a selection is made in the dataGrid, the fields in the form will be filled out
            {
                int index = e.RowIndex;
                DataGridViewRow selectedRow = dataGridView1.Rows[index];

                textBoxFirstName.Text = selectedRow.Cells[0].Value.ToString();
                textBoxLastName.Text = selectedRow.Cells[1].Value.ToString();
                textBoxEmail.Text = selectedRow.Cells[2].Value.ToString();
                textBoxBusiness.Text = selectedRow.Cells[3].Value.ToString();
                textBoxOffice.Text = selectedRow.Cells[4].Value.ToString();
                textBoxIdeaDescription.Text = selectedRow.Cells[5].Value.ToString();
                textBoxScope.Text = selectedRow.Cells[6].Value.ToString();
                textBoxDate.Text = selectedRow.Cells[7].Value.ToString();
            }

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e) //randomly selects a record and the fields in the form will be filled out
        {
            int dataRecords;
            dataRecords = dataGridView1.RowCount - 1;
            textBoxRecords.Text = dataRecords.ToString();

            Random rnd = new Random();
            int randomNum = rnd.Next(dataRecords);
            randomNum = randomNum + 1;
            textBoxSelected.Text = randomNum.ToString();

            DataGridViewRow selectedRow = dataGridView1.Rows[(randomNum - 1)];

            textBoxFirstName.Text = selectedRow.Cells[0].Value.ToString();
            textBoxLastName.Text = selectedRow.Cells[1].Value.ToString();
            textBoxEmail.Text = selectedRow.Cells[2].Value.ToString();
            textBoxBusiness.Text = selectedRow.Cells[3].Value.ToString();
            textBoxOffice.Text = selectedRow.Cells[4].Value.ToString();
            textBoxIdeaDescription.Text = selectedRow.Cells[5].Value.ToString();
            textBoxScope.Text = selectedRow.Cells[6].Value.ToString();
            textBoxDate.Text = selectedRow.Cells[7].Value.ToString();
        }
    }
}
