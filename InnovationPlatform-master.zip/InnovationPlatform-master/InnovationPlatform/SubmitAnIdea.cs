﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnovationPlatform
{
    public partial class SubmitAnIdea : Form
    {
        User submitusr = new User();

        IdeaSubmitter idea = new IdeaSubmitter();

        private DBConnect dbConnect; //creates a new database connection
        public SubmitAnIdea(User welcomeusr)
        {
            InitializeComponent();

            submitusr.FirstName = welcomeusr.FirstName; //carries user data from welcome form
            submitusr.LastName = welcomeusr.LastName;
            submitusr.Email = welcomeusr.Email;

            textBoxFirstName.Text = submitusr.FirstName;
            textBoxLastName.Text = submitusr.LastName;
            textBoxEmail.Text = submitusr.Email;

            dbConnect = new DBConnect(idea);
        }

        private void submitAnIdeaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SubmitAnIdea sAIForm = new SubmitAnIdea(submitusr);
            sAIForm.Show();
            this.Dispose(false);
        }

        private void welcomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Welcome welcomeForm = new Welcome(submitusr);
            welcomeForm.Show();
            this.Hide();
        }

        private void reviewIdeasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReviewIdeas rIForm = new ReviewIdeas(submitusr);
            rIForm.Show();
            this.Dispose(false);
        }
        private void voteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VoteIdeas vIForm = new VoteIdeas(submitusr);
            vIForm.Show();
            this.Dispose(false);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ResetErrors();
            if (ValidateForm())
            {

                idea.FirstName = textBoxFirstName.Text;
                idea.LastName = textBoxLastName.Text;
                idea.Email = textBoxEmail.Text;
                idea.Business = comboBoxBusinessUnit.SelectedItem.ToString();
                idea.Office = comboBoxOffice.SelectedItem.ToString();
                idea.Description = textBoxIdeaDescription.Text;

                bool status;
                string statusMessage;

                if (radioButtonClient.Checked == true)
                {
                    idea.Scope = "Client";
                }
                else if (radioButtonCost.Checked == true)
                {
                    idea.Scope = "Cost";
                }
                else if (radioButtonPersonnel.Checked == true)
                {
                    idea.Scope = "Personnel";
                }
                else if (radioButtonProcess.Checked == true)
                {
                    idea.Scope = "Process";
                }
                else if (radioButtonSchedule.Checked == true)
                {
                    idea.Scope = "Schedule";
                }
                else if (radioButtonSoftware.Checked == true)
                {
                    idea.Scope = "Software";
                }
                else if (radioButtonTechnology.Checked == true)
                {
                    idea.Scope = "Technology";
                }
                else if (radioButtonTools.Checked == true)
                {
                    idea.Scope = "Tools";
                }
                else if (radioButtonVendor.Checked == true)
                {
                    idea.Scope = "Vendor";
                }
                else
                {
                    idea.Scope = "Other";
                }

                DialogResult result = MessageBox.Show("Do you want to submit this idea?" + Environment.NewLine + idea.FirstName + " " + idea.LastName + Environment.NewLine + idea.Email + Environment.NewLine + idea.Business + Environment.NewLine + idea.Office + Environment.NewLine + idea.Description + Environment.NewLine + idea.Scope, "Submit", MessageBoxButtons.OKCancel, MessageBoxIcon.Information); /*Environment.NewLine is what will add a newline to the message box*/
                if (result.Equals(DialogResult.OK))
                {
                    status = dbConnect.Insert(idea);
                    if (status == true)
                    {
                        statusMessage = "Thank You!" + Environment.NewLine + "You Idea Has Been Submitted";
                        SubmitAnIdea sAIForm = new SubmitAnIdea(submitusr);
                        sAIForm.Show();
                        this.Dispose(false);
                    }
                    else
                    {
                        statusMessage = "Error, Please Try Again";
                    }

                    MessageBox.Show(statusMessage);
                }
                else
                {
                }
            }
        }

        private void SubmitAnIdea_Load(object sender, EventArgs e)
        {

        }

        private void textBoxIdeaDescription_TextChanged(object sender, EventArgs e)
        {
            errorProvider.SetError(textBoxIdeaDescription, ""); //resets individual errors when text is entered
        }

        private void comboBoxBusinessUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            errorProvider.SetError(comboBoxBusinessUnit, ""); //resets individual errors when selection is made
        }
        private void comboBoxOffice_SelectedIndexChanged(object sender, EventArgs e)
        {
            errorProvider.SetError(comboBoxOffice, ""); //resets individual errors when selection is made
        }
        private void groupBoxScope_Enter(object sender, EventArgs e)
        {

        }

        private bool ValidateForm() //validates if form has data in each field
        {
            bool valid = true;

            if (comboBoxBusinessUnit.SelectedIndex == -1) //nothing selected
            {
                valid = false;
                comboBoxBusinessUnit.Focus();
                errorProvider.SetError(comboBoxBusinessUnit, "Please select your business unit !");
            }
            if (comboBoxOffice.SelectedIndex == -1) //nothing selected
            {
                valid = false;
                comboBoxOffice.Focus();
                errorProvider.SetError(comboBoxOffice, "Please select your office location !");
            }
            if (string.IsNullOrEmpty(textBoxIdeaDescription.Text)) //if field is empty
            {
                valid = false;
                textBoxIdeaDescription.Focus();
                errorProvider.SetError(textBoxIdeaDescription, "Please enter your idea description !");
            }

            return valid;

        }

        private void ResetErrors() //resets errors before validation
        {
            errorProvider.SetError(comboBoxBusinessUnit, "");
            errorProvider.SetError(comboBoxOffice, "");
            errorProvider.SetError(textBoxIdeaDescription, "");
        }
    }
}
