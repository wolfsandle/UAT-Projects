﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnovationPlatform
{
    static class Program
    {
        /// <summary>
        /// This program was designed to fill a need in my company, but one that I think is also apparent in many other.
        /// It allows employees of a company to submit ideas fro innovation that the company can choose to implement.
        /// By allowing employees to vote on other ideas, we use the knowledge of the crowd to pick the best ideas.
        /// We are allowing each employee one vote per idea. A future improvement will be to allow a portal link, and also a search
        /// function which will allow you to  find ideas based on keyworks of interest, business units, etc.
        /// 
        /// When I started this program, I though that it might take me the the equivalent of 25 hours of continuous work. What I found
        /// to be the most time consuming aspect was finding how to execute something that I wanted to do with code in c# that would match. 
        /// Google was a time saver and a curse. It allowed me to find most things that ultimately worked, but at thew cost of hours of research. 
        /// The total time that I spent on this project was over 80 hours. This is not a true reflection on the time it should have taken, 
        /// but on my skill level. A huge benefit of this project is that I now have code snippets to do things that I may want to in the future
        /// such as interacting with a MySQL  database. Thanks to Dr. Jill Coddington for all of the help!
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Login());
        }
    }
}
