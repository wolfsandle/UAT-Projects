﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InnovationPlatform
{
    public class User
    {
        public string firstName = "FNAME";
        private string lastName = "LNAME";
        private string email = "EMAIL";

        public string FirstName
        {
            get { return firstName; }
            set { firstName = value; }
        }
        public string LastName
        {
            get { return lastName; }
            set { lastName = value; }
        }

        public string Email
        {
            get { return email; }
            set { email = value; }
        }
    }

    class IdeaSubmitter : User
    {
        private string business = "BUSINESS";
        private string office = "OFFICE";
        private string description = "DESCRIPTION";
        private string scope = "SCOPE";


        public string Business
        {
            get { return business; }
            set { business = value; }
        }

        public string Office
        {
            get { return office; }
            set { office = value; }
        }

        public string Description
        {
            get { return description; }
            set { description = value; }
        }

        public string Scope
        {
            get { return scope; }
            set { scope = value; }
        }
    }

    class Voter : User
    {
        private int voteid = 0;

        public int VoteID
        {
            get { return voteid; }
            set { voteid = value; }
        }
    }
}
