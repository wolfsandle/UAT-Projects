﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnovationPlatform
{
    public partial class Login : Form
    {
        public User loginusr = new User();

        public Login()
        {
            InitializeComponent();

            //firstName.Text = "Charlie";     for testing
            //lastName.Text = "Wolfsandle";
            //email.Text = "wolfsandle@gmail.com";
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            ResetErrors(); //resets errors before validation
            if (ValidateForm()) //validates form fields
            {

                loginusr.FirstName = firstName.Text;
                loginusr.LastName = lastName.Text;
                loginusr.Email = email.Text;


                {

                        Welcome welcomeForm = new Welcome(loginusr);
                        welcomeForm.Show();
                        this.Hide();

                }
            }

        }

        private void firstName_TextChanged(object sender, EventArgs e) //resets individual errors when text is entered
        {
            errorProviderLogin.SetError(firstName, "");
        }

        private void lastName_TextChanged(object sender, EventArgs e) //resets individual errors when text is entered
        {
            errorProviderLogin.SetError(lastName, "");
        }
        private void email_TextChanged(object sender, EventArgs e) //resets individual errors when text is entered
        {
            errorProviderLogin.SetError(email, "");
        }
        private bool ValidateForm() //validates if form has data in each field
        {
            bool valid = true;

            if (string.IsNullOrEmpty(firstName.Text)) //if field is empty
            {
                valid = false;
                firstName.Focus();
                errorProviderLogin.SetError(firstName, "Please Enter First Name !");
            }
            if (string.IsNullOrEmpty(lastName.Text)) //if field is empty
            {
                valid = false;
                lastName.Focus();
                errorProviderLogin.SetError(lastName, "Please Enter Last Name !");
            }
            if (string.IsNullOrEmpty(email.Text)) //if field is empty
            {
                valid = false;
                email.Focus();
                errorProviderLogin.SetError(email, "Please Enter Email Address !");
            }

            return valid;

        }

        private void ResetErrors() //resets all error notifications
        {
            errorProviderLogin.SetError(firstName, "");
            errorProviderLogin.SetError(lastName, "");
            errorProviderLogin.SetError(email, "");
        }
    }
}
