﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnovationPlatform
{
    public partial class VoteIdeas : Form
    {
        Voter voteusr = new Voter();

        private DBConnect dbConnect;
        public VoteIdeas(User submitusr) //carries user data from submit to vote form
        {
            InitializeComponent();

            voteusr.FirstName = submitusr.FirstName;
            voteusr.LastName = submitusr.LastName;
            voteusr.Email = submitusr.Email;

            dbConnect = new DBConnect(voteusr);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBoxSelected.Text.Trim()))
            {
                MessageBox.Show("Please select an idea to vote for.");
            }
            else
            {
                voteusr.VoteID = int.Parse(textBoxSelected.Text);
                string voteStatus;
                string statusMessage = "none";

                voteStatus = dbConnect.Vote(voteusr);
                //MessageBox.Show("returned status = " + voteStatus);
                if (voteStatus == "true")
                {
                    statusMessage = "Thank You!" + Environment.NewLine + "Your vote has been recorded.";
                    VoteIdeas vIForm = new VoteIdeas(voteusr);
                    vIForm.Show();
                    this.Dispose(false);
                }
                if (voteStatus == "voted")
                {
                    statusMessage = "Sorry," + Environment.NewLine + "You have already voted for this idea.";

                }
                if (voteStatus == "error")
                {
                    statusMessage = "Error, Please Try Again";
                }
                MessageBox.Show(statusMessage);
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1) //if a selection is made in the dataGrid, the fields in the form will be filled out 
            {
                int index = e.RowIndex;
   
                DataGridViewRow selectedRow = dataGridView1.Rows[index];

                textBoxFirstName.Text = selectedRow.Cells[0].Value.ToString();
                textBoxLastName.Text = selectedRow.Cells[1].Value.ToString();
                textBoxEmail.Text = selectedRow.Cells[2].Value.ToString();
                textBoxBusiness.Text = selectedRow.Cells[3].Value.ToString();
                textBoxOffice.Text = selectedRow.Cells[4].Value.ToString();
                textBoxIdeaDescription.Text = selectedRow.Cells[5].Value.ToString();
                textBoxScope.Text = selectedRow.Cells[6].Value.ToString();
                textBoxDate.Text = selectedRow.Cells[7].Value.ToString();
                textBoxSelected.Text = selectedRow.Cells[8].Value.ToString();
                textBoxVotes.Text = selectedRow.Cells[9].Value.ToString();

            }
        }

        private void reviewIdeasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ReviewIdeas rIForm = new ReviewIdeas(voteusr);
            rIForm.Show();
            this.Dispose(false);
        }

        private void welcomeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Welcome welcomeForm = new Welcome(voteusr);
            welcomeForm.Show();
            this.Hide();
        }

        private void submitAnIdeaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SubmitAnIdea sAIForm = new SubmitAnIdea(voteusr);
            sAIForm.Show();
            this.Dispose(false);
        }

        private void VoteIdeas_Load_1(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'innovateDataSet.idea' table. You can move, or remove it, as needed.
            this.ideaTableAdapter.Fill(this.innovateDataSet.idea);

        }
    }
}
