﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Data;
//Add MySql Library
using MySql.Data.MySqlClient;
using System.CodeDom;

namespace InnovationPlatform
{
    internal class DBConnect
    {
        private MySqlConnection connection;
        private string server;
        private string database;
        private string uid;
        private string password;
        private DataSet dataset;

        //Constructor
        public DBConnect(User idea)
        {
            Initialize();
        }

        //Initialize values
        private void Initialize()
        {
            server = "161.35.232.94";
            database = "innovate";
            uid = "innovate";
            password = "innovateordie";
            string connectionString;
            connectionString = "SERVER=" + server + ";" + "DATABASE=" + database + ";" + "UID=" + uid + ";" + "PASSWORD=" + password + ";";

            connection = new MySqlConnection(connectionString);
        }


        //open connection to database
        private bool OpenConnection()
        {
            try
            {
                connection.Open();
                return true;
            }
            catch (MySqlException ex)
            {
                //When handling errors, you can your application's response based on the error number.
                //The two most common error numbers when connecting are as follows:
                //0: Cannot connect to server.
                //1045: Invalid user name and/or password.
                switch (ex.Number)
                {
                    case 0:
                        MessageBox.Show("Cannot connect to server.  Contact administrator");
                        break;

                    case 1045:
                        MessageBox.Show("Invalid username/password, please try again");
                        break;
                }
                return false;
            }
        }

        //Close connection
        private bool CloseConnection()
        {
            try
            {
                connection.Close();
                return true;
            }
            catch (MySqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        //Insert statement
        public bool Insert(IdeaSubmitter idea)
        {
            string firstName = idea.FirstName;
            string lastName = idea.LastName;
            string email = idea.Email;
            string business = idea.Business; ;
            string office = idea.Office;
            string ideaDescription = idea.Description;
            string scope = idea.Scope;
            bool status;
            //string dateMySql = date.ToString("yyyy-MM-dd HH:mm");

            string query = "INSERT INTO innovate.idea(firstName,lastName,email,business,office,ideaDescription,scope) VALUES('" + firstName + "','" + lastName + "','" + email + "','" + business + "','" + office + "','" + ideaDescription + "','" + scope + "')";

            //open connection
            if (this.OpenConnection() == true)
            {
                //create command and assign the query and connection from the constructor
                MySqlCommand cmd = new MySqlCommand(query, connection);

                //Execute command
                cmd.ExecuteNonQuery();

                //close connection
                this.CloseConnection();
                status = true;
                return status;
            }
            else
            {
                status = false;
                return status;
            }
        }

        //Vote statement
        public string Vote(Voter voteusr)
        {
            string voteStatus = "none"; //true - vote allowed, voted - already voted, false - error
            string email = voteusr.Email;
            int id = voteusr.VoteID;
            string votereadquery = "SELECT * FROM innovate.votes WHERE email = '" + email + "' AND id = '" + id + "'"; /*COUNT(email)*/
            string votepostquery = "UPDATE innovate.idea SET votes = votes + 1 WHERE ID='" + id + "'";
            string voterecordquery = "INSERT INTO innovate.votes(email,id) VALUES(@email,@id)";

            //Open connection
            if (this.OpenConnection() == true)
            {
                //MessageBox.Show("connection opened...");
                MySqlCommand readvotecmd = new MySqlCommand(votereadquery, connection);
                MySqlCommand postvotecmd = new MySqlCommand(votepostquery, connection);
                MySqlCommand recordvotecmd = new MySqlCommand(voterecordquery, connection);
                MySqlDataReader voteResult = readvotecmd.ExecuteReader();

                if (voteResult.HasRows)
                {
                    voteStatus = "voted";
                    //MessageBox.Show("Vote row detected = '" + voteStatus + "'");
                }
                voteResult.Close();
            
                if (voteStatus != "voted")
                {
                    
                    recordvotecmd.Parameters.AddWithValue("@email", email);
                    recordvotecmd.Parameters.AddWithValue("@id", id);
                    //Execute command
                    recordvotecmd.ExecuteNonQuery();
                    voteStatus = "true";

                    //MessageBox.Show("2nd if Added line, Status for read = '" + voteStatus + "'");

                    postvotecmd.ExecuteNonQuery();



                }

                //close connection
                this.CloseConnection();
            }
            else
            {
                voteStatus = "error";
                //MessageBox.Show("else.. = '" + voteStatus + "'");
            }
            return voteStatus;
        }
    }
}
