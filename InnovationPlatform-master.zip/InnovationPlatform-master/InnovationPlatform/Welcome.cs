﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InnovationPlatform
{
    public partial class Welcome : Form
    {
        User welcomeusr = new User();


        public Welcome(User loginusr) //carries user data from login to welcome form
        {
            InitializeComponent();
            welcomeusr.FirstName = loginusr.FirstName;
            welcomeusr.LastName = loginusr.LastName;
            welcomeusr.Email = loginusr.Email;

            textBoxUser.Text = "Welcome, " + welcomeusr.FirstName;

        }

        private void submitButton_Click(object sender, EventArgs e)
        {

            Hide();
            SubmitAnIdea sAIForm = new SubmitAnIdea(welcomeusr);
            sAIForm.ShowDialog();

        }

        private void reviewButton_Click(object sender, EventArgs e)
        {
            Hide();
            ReviewIdeas rIForm = new ReviewIdeas(welcomeusr);
            rIForm.ShowDialog();
        }
        private void voteButton_Click(object sender, EventArgs e)
        {
            Hide();
            VoteIdeas vIForm = new VoteIdeas(welcomeusr);
            vIForm.ShowDialog();
        }
    }
}
